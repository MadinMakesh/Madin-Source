# Script to Split the Input and Create Pl file for each input and then execute each file and collect the whole output. 
#Created Date ::28-March-2017

use strict;
use Cwd;
use File::Copy;
use File::Copy qw(copy);
use File::Copy qw(move);
my $count=0;
my $c=1;
my $directory=getcwd();
use File::Path;
use File::Copy;
open AB,(">Status.txt");
close AB;
print "Enter the Input filename(You want to split the inputs)  :  ";
my $Inputfilename=<>;
print "Enter the PL  filename(You want to make a copy for all the input files) :";
my $perl_input_filename=<>;
$perl_input_filename=~s/^\s*//igs;
$perl_input_filename=~s/\s*$//igs;
my $perl_filename;
if($perl_input_filename=~m/^([^>]*?)\./is)
{
	$perl_filename=$1;
}
print "Enter the value to split  :  ";
my $noOFcount=<>;
print "File Number :: Input$c.......\n";
my @total_count;
push(@total_count,$c);
open FI,"$Inputfilename";
while(<FI>)
{
	my $inputs=$_;
	chomp($inputs);
	$count=$count+1;
	# print "Line Number $count Processing...\n";
	# my $filecount=$count%5000;
	my $filecount=$count%$noOFcount;
	open FO, (">>Input".$c.".txt");
	print FO $inputs."\n";
	close FO;
	if($filecount==0)
	{
		$c++;
		push(@total_count,$c);
		print "File Number :: Input$c.......\n";
	}
	
	
	
}
my @all_pl_files;
foreach my $each_count(@total_count)
{
	my $new_file=$perl_filename."_Input".$each_count."_Output".$each_count.".pl";
	push(@all_pl_files,$new_file);
	my $temp = $directory.$new_file;
	my $direcyty_new=$directory."/"."New";
	copy("$directory/$perl_input_filename","$directory/$new_file") or die "The copy operation failed: $!";
	

}

&auto_run;

status_again:
sleep(760);
&status_check;
sub status_check
{
	my $total_files=@total_count;
	my $size_count=0;
	open EF,("<Status.txt");
	while(<EF>)
	{
		$size_count++;
	}
	if($total_files==$size_count)
		{
			my @file_list=glob('*xxx.txt*');
			open FO,">Whole_Output.txt";

			foreach my $filename(@file_list)
			{
				chomp($filename);
				# print "File_name:$filename\n";
				open IN,"$filename";
				print FO <IN>;
				close IN;
			}
			close FO;
			print "\n****************Completed******************\n";
			exit;
		}
		else
		{
			goto status_again;
		}
}

sub auto_run
{
	
	foreach my $each_pl(@all_pl_files)
	{
		system('start '.$each_pl);
		# print "Started::::$each_pl\n";
	}
}














