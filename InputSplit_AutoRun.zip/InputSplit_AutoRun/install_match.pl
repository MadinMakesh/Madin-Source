use strict; 
# use warnings;
use LWP::Simple;
use List::MoreUtils qw(uniq);
use strict;
use LWP::Simple;
use Cwd;
use URI::Escape;
use LWP::UserAgent;
use HTTP::Cookies;
use URI::URL;
use HTML::Entities;
use Time::Piece;
use Lingua::EN::Words2Nums;
use Net::Address::IP::Local;
use URI::URL;
use URI::Escape;
use DateTime;
use strict;
# ***********************Want to add in your Script*******************************
use File::Basename;
my $name = basename($0);
$name=~s/^\s*//igs;
$name=~s/\s*$//igs;
my $input_filename;
if($name=~m/(Input[\d]+)\_/is)
{
	$input_filename=$1;
}
my $output_filename;
if($name=~m/\_(Output[\d]+)\./is)
{
	$output_filename=$1;
	$output_filename=$output_filename."xxx";
}
# **********************************************************************************
# open FO,">Output.txt";
# print FO "count\tstatus_code\turl\tbatch\tvalue1\n";
# close FO;

my $cookie_jar= HTTP::Cookies->new(file=>$0."_cookie.txt",autosave => 1,);
my $ua=LWP::UserAgent->new;
$ua->agent("Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36");
my $counter=0;
open FI,"$input_filename.txt";


while(<FI>)
{
    my($count,$batch,$url)=split('\t',$_);
    chomp($url,$batch,$count);
    
    $url=~s/http\:\/\///igs;
    $url=~s/https\:\/\///igs;
    $url=~s/www\.//igs;
    $url="http://www.".$url;
  
    my $value1;
    $counter++;
    my ($content,$status_code)=getcont($url,"","","GET");
    # open FA,(">content.html");
    # print FA "$content\n";
    # close FA;
    
    print "< $counter > $url\n";
    
    open FO,">>$output_filename.txt";
    print FO "$count\t$status_code\t$url\t$batch\t";
    close FO;
    
    
    # if(($status_code=~m/50/is)||($status_code=~m/40/is))
    # {
        # my $status="In Active";
        # open FO,">>Output.txt";
        # print FO "$count\t$status_code\t$url\t$batch\n";
        # close FO;
    # }
    # else
    # {
        $content=~s/<style[^>]*?>[\w\W]*?<\/style>//igs;
        $content=~s/<script[^>]*?>[\w\W]*?<\/script>//igs;
        $content=~s/<[^>]*?>//igs;
        $content=~s/<\/[^>]*?>//igs;
        $content=~s/\s+/ /igs;

        # print "Content$content\n";
        # my @wa=split(".",$content);
        my @wa = split /\./, $content;
        
        my ($ai,$bi);
        for (my $i=0;$i<=$#wa;$i++)
        {
            # print "Install inside for $keyword\n";
            # print "\n\n$wa[$i]\n";
            if($wa[$i]=~m/install/is)
            {
                my $value=$wa[$i];
                $value=trim_space($value);
                $value1="$value1|***|$value";
                
            }
        }
        if($value1 ne "")
        {
            open FO,">>$output_filename.txt";
            print FO "$value1\t";
            close FO;
            
        }
            
    # }
    open FO,">>$output_filename.txt";
    print FO "\n";
    close FO;
    
}
# ***********************Want to add in your Script*******************************
print "$output_filename\tCompleted\n";
open AB,(">>Status.txt");
print AB "$output_filename\tCompleted\n";
close AB;
# **********************************************************************************

sub trim_space
{
    my $str=shift;
    $str=~s/\s+/ /igs;
    $str=~s/^\s//igs;
    $str=~s/\s$//igs;
    return $str;
}

#----------------GET CONTENT-------------------#
sub getcont
{
    my($ur,$cont,$ref,$method)=@_;
    my $cc=0;
    netfail:
    my $request=HTTP::Request->new("$method"=>$ur);
    $request->header("Content-Type"=>"application/x-www-form-urlencoded");
    $request->header("Cookie"=>"CFID=35231955; CFTOKEN=a102a537f89e45dc-18CB8AE8-D034-7E24-B9315C57BE0AB8CE; _ceg.s=oc3b79; _ceg.u=oc3b79; _ga=GA1.2.354458192.1471434376; _ceg.s=oc1y8l; _ceg.u=oc1y8l; BIGipServerPOOL-207.97.254.104-80=156084416.20480.0000; _gat=1; _gat_GSA_ENOR0=1");
    if($ref ne '')
    {
   
        $request->header("Referer"=>"$ref");
    }
    if(lc $method eq 'post')
    {
   
        $request->content($cont);
    }
    my $res=$ua->request($request);
    $cookie_jar->extract_cookies($res);
    $cookie_jar->save;
    $cookie_jar->add_cookie_header($request);
    my $code=$res->code;
    print"\nRESPONSE CODE:$code\n";
    if($code==200)
    {
       
        my $content=$res->content();
		#$content=decode_entities($content);
        return ($content,$code);
    }
    elsif($code=~m/50/is)
    {
        print"\n Net Failure";
        $cc++;
        if($cc==4)
        {
            return ("",$code);
            next;
        }
        # sleep(30);
        goto netfail;
    }
    elsif($code=~m/30/is)
    {
       
       my $loc=$res->header("Location");
         print "\nLocation: $loc";
        my $request1=HTTP::Request->new(GET=>$loc);
        $request1->header("Content-Type"=>"application/x-www-form-urlencoded; charset=UTF-8");
        my $res1=$ua->request($request1);
        $cookie_jar->extract_cookies($res1);
        $cookie_jar->save;
        $cookie_jar->add_cookie_header($request1);
        my $content1=$res1->content();
        return ($content1,$code);

    }
    elsif($code=~m/40/is)
    {
		 my $content=$res->content();
		#$content=decode_entities($content);
		print "\n URL Not found";
        return ($content,$code);
        
    }
}	