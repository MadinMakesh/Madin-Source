use strict;
open FA, (">output4.txt");
print FA "Product Name\tiId\tNew productName\tModel no\tRemark\tComments\n" ;
close FA;
open FH,("<input.txt");
while(<FH>)
{
	my($Product_Name,$iId,$Product_Description,$Code_Information,$SNo,$Ao_Statements,$iProductMstr_ID,$Source)=split("\t",$_);
	chomp($SNo,$iId,$iProductMstr_ID,$Source,$Product_Name,$Ao_Statements,$Product_Description	,$Code_Information);
	my $model_name;
	my @number;
	print "$Product_Name\n";
	my $fl=$Product_Name;
	my $se=$Ao_Statements;
	my $tr=$Product_Description;
	my $fr=$Code_Information;
	my @del;
	my $and;
	if($fl ne "")
	{
		$fl=~s/^\s*//;
		$fl=~s/^\s+//;
		$fl=~s/\s+/ /;
		# $fl=~s/^Models\://is;
		# $fl=~s/^Models//igs;
		# $fl=~s/^Model//igs;
		# $fl=~s/^Models//igs;
		# $fl=~s/^Models//igs;
		# $fl=~s/\s*(?:Model|Models|Models\s*\:|Models |model[^>]*?\:\s*)//igs;
		# $fl=~s/^s\://igs;
		# print "fl::::$fl\n";<>;
		chomp($fl);
		
		my @array1=split(" ",$fl);
		if($#array1<=2)
		{
			 @array1=split("(?:\,|\:)",$fl);
		}
		if(@array1 ne "")
		{
			@array1=split(" ",$fl);
		}
		my @array;
		foreach my $a(@array1)
		{
			if($a ne "")
			{
				push(@array,$a);
			}
		}
		# print "$array[0]\n";<>;
		# print "$array[1]\n";<>;
		# foreach my $array(@array)
		
		for(my $i=0;$i<=$#array;$i++)
		{
			# print "aaaa$array[$i]\n";<>;
			if(($array[$i]=~m/\d+/igs) && ($i>0))
			{
				# print "bbbb$array[$i-1]\n";<>;
				push(@del,$array[$i-1]);
				chomp($array[$i-1]);
				if($array[$i-1]=~m/\&/is)
					{
						$and=1;
						# print "and::$and";<>;
					}
				if($array[$i-1]=~m/(?: MODEL|MODEL|Model|\d+|and|#|Number\:|MODEL|Number)/igs)
				{
					
					# print "eeee$array[$i]\n";<>;
					$array[$i]=~s/\,$//igs;
					if($array[$i]=~m/(?:\,|\/|\;)/)
					{
						my @a=split("\,|\;",$array[$i]);
						foreach my $b(@a)
						{
							push(@number,$b);
						}
					}
					else
					{
						push(@number,$array[$i]);
					}
				}
				elsif($array[$i-1] eq "&")
				{
					# print "dd$array[$i]\n";<>;
					# print "cccc$array[$i-1]\n";<>;
					push(@number,$array[$i]);
				}
				elsif($array[$i-1]=~m/[\d]+/igs)
				{
					# print "dd$array[$i]\n";<>;
					# print "cccc$array[$i-1]\n";<>;
					push(@number,$array[$i]);
				}
				elsif($array[$i-1] eq "ET")
				{
					# print "dd$array[$i]\n";<>;
					# print "cccc$array[$i-1]\n";<>;
					push(@number,$array[$i]);
				}
				else
				{
					# print "ddddarray[$i]\n";<>;
					$model_name=$model_name." ".$array[$i];
				}
				
				
				
			}else
			{
				# if($array[$i] eq "&")
				# {
					# $array[$i]="";
				# }
					# print "dddd$array[$i]\n";<>;
				$model_name=$model_name." ".$array[$i];
				$model_name=~s/^Models\://is;
				$model_name=~s/^Models//igs;
				$model_name=~s/^Model//igs;
			}
		}
		
	}
	my @comp=($se,$tr,$fr);
	foreach my $comp(@comp)
	{
		if($comp ne "")
		{
			$comp=~s/^\s*//;
			$comp=~s/^\s+//;
			$comp=~s/\s+/ /;
			chomp($comp);
			my @array_a=split(" ",$comp);
			my @array_b;
			foreach my $a(@array_a)
			{
				if($a ne "")
				{
					push(@array_b,$a);
				}
			}
			for(my $i=0;$i<=$#array_b;$i++)
			{
				# print "aaaa$array[$i]\n";<>;
				if(($array_b[$i]=~m/\d+/igs) && ($i>0))
				{
					chomp($array_b[$i-1]);
					if($array_b[$i-1]=~m/(?:Model|\d+|and|#)/igs)
					{
						# print "eeee$array[$i]\n";<>;
						$array_b[$i]=~s/\,$//igs;
						if($array_b[$i]=~m/(?:\,|\/|\;)/)
						{
							my @a=split("\,|\;",$array_b[$i]);
							foreach my $b(@a)
							{
								push(@number,$b);
							}
						}
						else
						{
							push(@number,$array_b[$i]);
						}
					}
					elsif($array_b[$i-1] eq "&")
					{
						# print "dd$array[$i]\n";<>;
						# print "cccc$array[$i-1]\n";<>;
						push(@number,$array_b[$i]);
					}
					elsif($array_b[$i-1]=~m/[\d]+/igs)
					{
						# print "dd$array[$i]\n";<>;
						# print "cccc$array[$i-1]\n";<>;
						push(@number,$array_b[$i]);
					}
					elsif($array_b[$i-1] eq "ET")
					{
						# print "dd$array[$i]\n";<>;
						# print "cccc$array[$i-1]\n";<>;
						push(@number,$array_b[$i]);
					}
					
				}
			}	
		}
	}	
	$model_name=~s/Models//igs;
	$model_name=~s/Model//igs;
	$model_name=~s/number\s*\://igs;
	$model_name=~s/^\s*//igs;
	$model_name=~s/^\&//igs;
	$model_name=~s/^&//igs;
	# print "model_name$model_name\n";<>;
	
	my @number1;
	@number = grep /\S/, @number;
	# foreach my $bbb(@number)
	# {
		# $bbb=~s/\s*//;
		# if($bbb ne "")
		# {
			# push(@number1,$bbb);
		# }
	# }
	$model_name=~s/^Model//igs;
	# print "$#number\n";
	# print "number@number\n";<>;
	# foreach my $del(@del)
	# {
		# $model_name=s/$del/ /igs;
		# if($model_name=~m/$del/is)
		# {
			
		# }
	# }
	if(@number)
	{
		my $additional;
		my $flag=0;
		# print "yes\n";<>;
		foreach my $model_number(@number)
		{
			$flag++;
			if($flag>1)
			{
				$additional="Additional"; 
			}
			$model_name=~s/^\s*//igs;
			$model_name=~s/\s*$//igs;
			chomp($model_name);
			$model_name=~s/^\&//igs;
			$model_name=~s/Models//igs;
			$model_name=~s/Model//igs;
			$model_name=~s/number\s*\://igs;
			$model_name=~s/#$//igs;
			$model_name=~s/\(S$\s*//igs;
			$model_name=~s/and$//igs;
			$model_name=~s/\,$//igs;
			$model_name=~s/\/$//igs;
			$model_name=~s/\:$//igs;
			$model_name=~s/\:$//igs;
			$model_name=~s/\&$//igs;
			$model_name=~s/\,$//igs;
			$model_name=~s/\.$//igs;
			$model_name=~s/\($//igs;
			$model_name=~s/\)$//igs;
			if(($model_name eq ":")||($model_name eq "&"))
			{
				$model_name="";
			}
			# print "Model_name:::::$model_name\n";<>;
			# print "model_number:::::$model_number\n";<>;
			if($and==1)
			{
				$and="& found"
			}
			else
			{
				$and="";
			}
			chomp($model_number);
			open FA, (">>output4.txt");
			print FA "$Product_Name\t$iId\t$model_name\t$model_number\t$additional\t$and\n";
			close FA;
			
		}
	}
	else
	{
			# print "no\n";<>;
			$model_name=~s/^\s*//igs;
			$model_name=~s/^\&//igs;
			$model_name=~s/\s*$//igs;
			chomp($model_name);
			$model_name=~s/Models//igs;
			$model_name=~s/Model//igs;
			$model_name=~s/number\s*\://igs;
			$model_name=~s/#$//igs;
			$model_name=~s/\(S$\s*//igs;
			$model_name=~s/\s*//igs;
			$model_name=~s/and$//igs;
			$model_name=~s/\,$//igs;
			$model_name=~s/\/$//igs;
			$model_name=~s/\:$//igs;
			$model_name=~s/\:$//igs;
			$model_name=~s/\&$//igs;
			$model_name=~s/\,$//igs;
			$model_name=~s/\.$//igs;
			$model_name=~s/\($//igs;
			$model_name=~s/\)$//igs;
			if(($model_name eq ":")||($model_name eq "&"))
			{
				$model_name="";
			}
			if($and==1)
			{
				$and="& found"
			}
			else
			{
				$and="";
			}
			# print "model_name$model_name\n";<>;
			open FA, (">>output4.txt");
			print FA "$Product_Name\t$iId\t$model_name\t\t\t$and\n";
			close FA;
	}
	
}

# if($fl=~m/\s+([^>]*?\d+[^>]*?)(?:\,|\&|\/|\s+)/is)
		# {
			# my $model_number=$1;
			# my $model_name=$2;
			# if($model_number=~m/(\&|\,|\/)/is)
			# {
				# my $value=$1;
				# my @array=split($value,$model_number);
				# foreach my $array(@array)
				# {
					# open FA, (">>output.txt");
					# print FA "$model_name\t$array\n";
					# close FA;
				# }
			# }
			# else
			# {
					# open FA, (">>output.txt");
					# print FA "$model_name\t$model_number\n";
					# close FA;
			# }
		# }
		# elsif($fl=~m/(\&|\,|\/)/igs)
		# {
				# my $value=$1;
				# my @array=split($value,$fl);
				# foreach my $array(@array)
				# {
					# open FA, (">>output.txt");
					# print FA "\t$array\n";
					# close FA;
				# }
			
		# }